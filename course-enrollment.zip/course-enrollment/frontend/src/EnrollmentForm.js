import React, { useState } from 'react';
import axios from 'axios';

const courses = ["React Basics", "Node.js Essentials", "MongoDB 101", "Full Stack Bootcamp"];

export default function EnrollmentForm() {
  const [formData, setFormData] = useState({
    studentName: '',
    email: '',
    courseName: courses[0]
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/enrollments', formData);
      alert('✅ Enrollment successful!');
      setFormData({ studentName: '', email: '', courseName: courses[0] });
    } catch (err) {
      alert('❌ Error enrolling student');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Enroll in a Course</h2>
      <input
        name="studentName"
        placeholder="Student Name"
        value={formData.studentName}
        onChange={handleChange}
        required
      />
      <input
        name="email"
        type="email"
        placeholder="Email"
        value={formData.email}
        onChange={handleChange}
        required
      />
      <select name="courseName" onChange={handleChange} value={formData.courseName}>
        {courses.map(course => (
          <option key={course}>{course}</option>
        ))}
      </select>
      <button type="submit">Enroll Now</button>
    </form>
  );
}
