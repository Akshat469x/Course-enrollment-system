import React from 'react';
import EnrollmentForm from './EnrollmentForm';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <EnrollmentForm />
    </div>
  );
}

export default App;
