const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');

// POST: Create new enrollment
router.post('/', async (req, res) => {
  try {
    const { studentName, email, courseName } = req.body;
    const newEnrollment = new Enrollment({ studentName, email, courseName });
    await newEnrollment.save();
    res.status(201).json(newEnrollment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
