const mongoose = require('mongoose');

const EnrollmentSchema = new mongoose.Schema({
  studentName: String,
  email: String,
  courseName: String,
  enrollDate: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Enrollment', EnrollmentSchema);
